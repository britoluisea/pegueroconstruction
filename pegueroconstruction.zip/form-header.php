<!-- contacto -->
  <section id="contacto"   >
    <div class="container">
      <div class="col-md-12">
        <form action="" method="POST" class="form2">
          <div class="form-group full-name col-sm-4">
            <input type="text" class="form-control" id="" placeholder="FULL NAME">
          </div>
          <div class="form-group phone col-sm-4">
            <input type="text" class="form-control" id=""  placeholder="PHONE">
          </div>
          <div class="form-group email col-sm-4">
            <input type="text" class="form-control" id=""  placeholder="EMAIL">
          </div>
          <div class="form-group message col-sm-8">
            <textarea class="form-control" id=""  placeholder="MESSAGE" ></textarea>
          </div>
          <div class="form-group   col-sm-4">
            <button type="submit" class="btn btn-success   " style="margin-top: 0px;" >SEND MESSAGE</button>
          </div>
        </form>
      </div>
    </div>
  </section>