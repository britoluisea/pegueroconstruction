        <!-- Footer widget -->
        <footer style="background-color: rgba(42, 39, 39, 0.61);">
            <div class="container">
                <div class="col-sm-4 wfood">
                    <h4 class="t-fw">
                        PEGUERO CONTRUCTION
                    </h4>
                    <p><a  href="<?=URL_INDEX?>"><img src="<?=IMG?>logo.png" alt="logo" style="width:150px;"></a></p>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minus saepe, quidem laudantium maiores tenetur deserunt quae porro in, autem error ab? Et provident fuga cumque accusamus, esse excepturi quia adipisci.</p>
                    <ul class="list-inline footer_social_icon">
                        <li><a href=""><span class="fa fa-facebook fa-lg"></span></a></li>
                        <li><a href=""><span class="fa fa-twitter fa-lg"></span></a></li>
                        <li><a href=""><span class="fa fa-google-plus fa-lg"></span></a></li>
                    </ul>
                </div>
                <div class="col-sm-4 wfood">
                    <h4 class="t-fw">Contact us now</h4>
                    <div class="col-md-12">
                        <a href="#"><span class="fa fa-map-marker"></span> 124 New Line, London UK</a>
                    </div>
                    <div class="col-md-12">
                        <a href="#"><span class="fa fa-envelope"></span> info@Construct.com</a>
                    </div>
                    <div class="col-md-12">
                        <a href="#"><span class="fa fa-phone"></span> (617) - 888 - 4609</a>
                    </div>
                </div>
                <div class="col-sm-4 wfood">
                    <h4 class="t-fw">Follow us Facebook</h4>
                    <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Fmasonideas%2F&tabs=timeline&width=350&height=350&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="280" height="300" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
                </div>
            </div>
        </footer>
         <!-- Footer copy-->
        <footer>
            <div class="container">
                <div class="col-lg-12">
                    <p>Design & Development by: <a href="http://amwebpro.com/"> AM Web Pro Inc</a></p>
                </div>
            </div>
        </footer>