<div class="top-bar hidden-xs">
	<div class="container">
		<div class="col-sm-4"><a href="#"><span class="fa fa-phone"></span> (617) - 888 - 4609</a></div>
		<div class="col-sm-4"><a href="#"><span class="fa fa-envelope"></span> info@Construct.com</a></div>
		<div class="col-sm-4"><a href="#"><span class="fa fa-clock-o"></span> Mon - Sat 9:00 - 19:00</a></div>
	</div>
</div>