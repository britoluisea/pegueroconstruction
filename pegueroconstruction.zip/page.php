<?php include"header.php"; ?>
  <!--OUR MISSION -->
  <section id="our-mission" >
    <div class="container">
      <div class="col-md-12">

        <h1 class="page-header">
             About Us
        </h1>
      </div>
      <div class="col-md-8">
                <h4 class="text-description">
                 To ensure long-term client relationships through the design and management of comprehensive energy procurement strategies that exceed customer expectations by communicating market knowledge, leveraging supplier relationships, identifying unique product options, and implementing innovative solutions.
                </h4>
                <h4 class="text-description">
                 To ensure long-term client relationships through the design and management of comprehensive energy procurement strategies that exceed customer expectations by communicating market knowledge, leveraging supplier relationships, identifying unique product options, and implementing innovative solutions.
                </h4>
                <h4 class="text-description">
                 To ensure long-term client relationships through the design and management of comprehensive energy procurement strategies that exceed customer expectations by communicating market knowledge, leveraging supplier relationships, identifying unique product options, and implementing innovative solutions.
                </h4>
            </div>
      <div  class="col-md-4 ">
        <img src="<?=IMG?>services/roofing.jpg" alt="about"  class="img-responsive ">
        <h2>Roofing</h2>
        <img src="<?=IMG?>services/siding.jpg" alt="about"  class="img-responsive ">
        <h2>Siding</h2>
        <img src="<?=IMG?>services/windows.jpg" alt="about"  class="img-responsive ">
        <h2>Windows</h2>
      </div>
    </div>
  </section>

<?php include"food.php"; ?> 